#ifndef DRIVER_ADC_H_
#define DRIVER_ADC_H_


void adc_init(void);
void adc_read_putty(void);
void adc_ballpoint(void);


#endif 