#ifndef UTIL_H_
#define UTIL_H_

void util_swap(int *p,int *q);
void util_sort(int a[],int n);
int util_median(int a[], int n);

#endif